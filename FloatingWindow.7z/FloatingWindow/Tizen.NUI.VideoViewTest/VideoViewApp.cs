﻿/*
 * Copyright (c) 2020 Samsung Electronics Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */
using System;
using Tizen.NUI.BaseComponents;
using Tizen.NUI.Components;

namespace Tizen.NUI.VideoViewTest
{
    public class VideoViewApplication : NUIApplication
    {
        private VideoView videoView = null;
        private Button button = null;

        private Vector2 lastWindowScreenPosition = Vector2.Zero;
        private Size lastWindowSize = Size.Zero;
        private Vector2 lastWindowPosition = Vector2.Zero;
        //private int count = 0;
        //private int buttonTouchCount = 0;

        private Vector2 lastButtonPosition = Vector2.Zero;

        protected override void OnCreate()
        {
            base.OnCreate();

            Window.Instance.Type = WindowType.Notification;
            Window.Instance.SetNotificationLevel(NotificationLevel.Top);
            Window.Instance.WindowPosition = new Position2D(200, 600);
            Window.Instance.WindowSize = new Size(500, 500);
            Window.Instance.TouchEvent += OnWindowTouchEvent;

            videoView = new VideoView(false);
            videoView.ResourceUrl = @"/opt/usr/globalapps/Tizen.NUI.VideoViewTest/res/test.mp4";
            videoView.HeightResizePolicy = ResizePolicyType.FillToParent;
            videoView.WidthResizePolicy = ResizePolicyType.FillToParent;
            //videoView.Looping = true;
            videoView.Play();
            Window.Instance.Add(videoView);

            button = new Button()
            {
                Size = new Size(100, 100),
                Text = "Drag",
                PositionUsesPivotPoint = true,
                PivotPoint = PivotPoint.BottomRight,
                ParentOrigin = ParentOrigin.BottomRight,
            };
            Window.Instance.Add(button);

            button.TouchEvent += OnButtonTouchEvent;
        }

        protected override void OnTerminate()
        {
            if (videoView != null)
            {
                Window.Instance.Remove(videoView);
                videoView.Dispose();
                videoView = null;
            }

            base.OnTerminate();
        }

        private bool OnButtonTouchEvent(object sender, View.TouchEventArgs e)
        {
            if (e.Touch.GetState(0) == PointStateType.Started)
            {
                Log.Info("test", $"moving window size..({Window.Instance.WindowSize.Width}, {Window.Instance.WindowSize.Height})..........");
                lastButtonPosition = e.Touch.GetScreenPosition(0);

                lastWindowSize = Window.Instance.WindowSize;
            }
            else if (e.Touch.GetState(0) == PointStateType.Motion)
            {
                //buttonTouchCount++;
                //if (buttonTouchCount % 10 != 0)
                //    return true;

                //buttonTouchCount = 0;

                int deltaX = (int)(e.Touch.GetScreenPosition(0).X - lastButtonPosition.X);
                int deltaY = (int)(e.Touch.GetScreenPosition(0).Y - lastButtonPosition.Y);

                int newWindowWidth = (int)lastWindowSize.Width + deltaX;
                if (newWindowWidth > 1080)
                {
                    newWindowWidth = 1080;
                }

                int newWindowHeight = (int)lastWindowSize.Height + deltaY;
                if (newWindowHeight > 1920)
                {
                    newWindowHeight = 1920;
                }

                Window.Instance.WindowSize = new Size(newWindowWidth, newWindowHeight);

                Log.Info("test", $"moving window size..({Window.Instance.WindowSize.Width}, {Window.Instance.WindowSize.Height})..........");
                lastButtonPosition = e.Touch.GetScreenPosition(0);
                lastWindowSize = Window.Instance.WindowSize;
            }
            return true;
        }

        private void OnWindowTouchEvent(object sender, Window.TouchEventArgs e)
        {
            if (e == null || e.Touch == null)
                return;

            if (e.Touch.GetState(0) == PointStateType.Started)
            {
                lastWindowScreenPosition = e.Touch.GetScreenPosition(0);

                lastWindowPosition = Window.Instance.WindowPosition;
                lastWindowSize = Window.Instance.WindowSize;

                Log.Info("test", $"touch event started..({lastWindowScreenPosition.X}, {lastWindowScreenPosition.Y})..........");
            }
            else if (e.Touch.GetState(0) == PointStateType.Motion)
            {
                //count++;
                //if (count % 10 != 0)
                //    return;

                //count = 0;

                int deltaX = (int)(e.Touch.GetScreenPosition(0).X - lastWindowScreenPosition.X);
                int deltaY = (int)(e.Touch.GetScreenPosition(0).Y - lastWindowScreenPosition.Y);

                int newDeltaX = (int)lastWindowPosition.X + deltaX;
                if (newDeltaX < 0)
                    newDeltaX = 0;

                int newDeltaY = (int)lastWindowPosition.Y + deltaY;
                if (newDeltaY < 0)
                    newDeltaY = 0;

                Window.Instance.WindowPosition = new Position2D(newDeltaX, newDeltaY);

                Log.Info("test", $"touch event moving. delta is ({deltaX}, {deltaY})...........");
                Log.Info("test", $"window postion is ({Window.Instance.WindowPosition.X}, {Window.Instance.WindowPosition.Y})");

                lastWindowPosition = Window.Instance.WindowPosition;
                lastWindowScreenPosition = e.Touch.GetScreenPosition(0);
            }
        }

        [STAThread]
        static void Main(string[] args)
        {
            new VideoViewApplication().Run(args);
        }
    }
}

